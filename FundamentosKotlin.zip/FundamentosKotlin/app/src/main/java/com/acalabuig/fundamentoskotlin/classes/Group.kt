package com.acalabuig.fundamentoskotlin.classes

enum class Group {
    FAMILY, WORK, FRIEND
}