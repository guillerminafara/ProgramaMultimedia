package com.acalabuig.fundamentoskotlin

fun main() {
    queTengo(5)
}

fun queTengo(num: Int): Unit {
    println("Tengo $num manzanas")
}