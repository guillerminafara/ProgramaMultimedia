package com.acalabuig.userssp

interface OnClickListener {
    fun onClick(user: User, position: Int) {}
}